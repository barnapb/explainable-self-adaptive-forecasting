import os
os.system('pip install pandas')
os.system('pip install gluonts')
import pandas as pd
import pathlib
import gluonts
import numpy as np
import argparse
import json
from mxnet import gpu, cpu
from mxnet.context import num_gpus
from gluonts.dataset.util import to_pandas
from gluonts.model.deepar import DeepAREstimator
from gluonts.model.simple_feedforward import SimpleFeedForwardEstimator
from gluonts.evaluation.backtest import make_evaluation_predictions, backtest_metrics
from gluonts.evaluation import Evaluator
from gluonts.model.predictor import Predictor
from gluonts.dataset.common import ListDataset, FileDataset
from gluonts.trainer import Trainer


def train(epochs, prediction_length, context_length, num_layers, dropout_rate, time_freq, num_cells, learning_rate):
    
    
    training_data = FileDataset(path=os.environ['SM_CHANNEL_TRAIN'], freq = time_freq, one_dim_target = True, cache = False)
    
    #define DeepAR estimator
    deepar_estimator = DeepAREstimator(freq=time_freq, 
                                       prediction_length=prediction_length,
                                       context_length=context_length,
                                       dropout_rate=dropout_rate,
                                       num_layers=num_layers,
                                       num_cells=num_cells,
                                       use_feat_dynamic_real=True,
                                       trainer=Trainer(epochs=epochs,learning_rate=learning_rate))
    
    #train the model
    deepar_predictor = deepar_estimator.train(training_data=training_data)
      
    
    test_data = FileDataset(path=os.environ['SM_CHANNEL_TEST'], freq = time_freq, one_dim_target = True, cache = False)
    
    #evaluate trained model on test data
    forecast_it, ts_it = make_evaluation_predictions(test_data, deepar_predictor,  num_samples=100)
    forecasts = list(forecast_it)
    tss = list(ts_it)
    evaluator = Evaluator(quantiles=[0.1, 0.5, 0.9])
    agg_metrics, item_metrics = evaluator(iter(tss), iter(forecasts), num_series=len(test_data))
    
    print("MSE:", agg_metrics["MSE"])
    
    #save the model
    deepar_predictor.serialize(pathlib.Path(os.environ['SM_MODEL_DIR']))
  
    return deepar_predictor


def model_fn(model_dir):
    path = pathlib.Path(model_dir)   
    predictor = Predictor.deserialize(path)
    
    return predictor

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--prediction_length', type=int, default=30)
    parser.add_argument('--context_length', type=int, default=30)
    parser.add_argument('--num_layers', type=int, default=2)
    parser.add_argument('--time_freq', type=str, default="D")
    parser.add_argument('--num_cells', type=int, default=40)
    parser.add_argument('--learning_rate', type=float, default=0.001)
    parser.add_argument('--dropout_rate', type=float, default=0.2)

    return parser.parse_args()

if __name__ == '__main__':
    args = parse_args()
    train(args.epochs, args.prediction_length, args.context_length, args.num_layers, args.dropout_rate, args.time_freq, args.num_cells, args.learning_rate)
    
